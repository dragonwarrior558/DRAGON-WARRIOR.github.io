const menuBtn = document.querySelector(".menu-btn");
const navLinks = document.querySelector(".nav-links");
const modal = document.querySelector(".modal");
const modalTitle = document.querySelector(".modal-title");
const modalClose = document.querySelector(".modal-close");

menuBtn.addEventListener("click", () => navLinks.classList.toggle("open"));

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

document.querySelectorAll(".read-more").forEach(link => {
  link.addEventListener("click", e => {
    e.preventDefault();
    modalTitle.textContent = link.dataset.title;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  });
});

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
modalClose.addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

document.getElementById("year").textContent = new Date().getFullYear();
